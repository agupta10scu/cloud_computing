CREATE TABLE IF NOT EXISTS Meals (
    MealId SERIAL PRIMARY KEY
    ,MealName TEXT NOT NULL
    ,MealPrice DECIMAL(10,2) NOT NULL
);

INSERT INTO Meals(MealName, MealPrice) VALUES ('Veg Biryani','$23.00');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Chicken pasta','$12.59');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Kadhai Paneer','$15.99');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Chole bature','$7.99');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Allo chaat','0.00');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Garlic bread','$12.00');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Latte','$4.99');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Sandwich','$8.59');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Rajma chaval','$19.00');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Chole chaval','$10.99');
INSERT INTO Meals(MealName, MealPrice) VALUES ('Yellow lentils','$11.00');
INSERT INTO Meals(MealName, MealPrice) VALUES ('south indian combo','$12.78');
INSERT INTO Meals(MealName, MealPrice) VALUES ('curd','$2.00');
INSERT INTO Meals(MealName, MealPrice) VALUES ('lemonade','$10.00');
INSERT INTO Meals(MealName, MealPrice) VALUES ('brownie','$2.50');
        